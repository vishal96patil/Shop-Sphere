package com.Techpalle.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BDcon {
	private static Connection connection = null;
	
	public static Connection getConnetion() throws ClassNotFoundException, SQLException {
		if(connection == null) {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecomm","root","Vishal@123");
			System.out.print("connected");
		}
		return connection;
	}
}
